window.addEventListener("DOMContentLoaded", () => {
    document.querySelector(".forgot-box").classList.add("loaded");
});